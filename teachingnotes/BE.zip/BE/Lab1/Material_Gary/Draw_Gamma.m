function y = Draw_Gamma(a,b)

% Generate Inverse Gamma random draws

y = gamrnd(a,1/b);